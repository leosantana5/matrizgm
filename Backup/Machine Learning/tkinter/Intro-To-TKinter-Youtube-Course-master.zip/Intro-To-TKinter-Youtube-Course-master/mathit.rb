print "Enter name: "
name = gets

puts name
