
my_dict = {"John":"Elder", "Mary":"Smith"}

for key in my_dict:
	print(key)