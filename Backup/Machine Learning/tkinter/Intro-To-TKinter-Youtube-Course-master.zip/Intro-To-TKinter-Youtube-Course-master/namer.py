def nameit(name):
	greetings = f'Hello {name}'
	return greetings

	